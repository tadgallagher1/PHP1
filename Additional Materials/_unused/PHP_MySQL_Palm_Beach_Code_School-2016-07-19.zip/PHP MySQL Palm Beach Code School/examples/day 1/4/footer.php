<nav class="navbar navbar-inverse navbar-fixed-bottom">
  <div class="container-fluid">
    <span style='color:white;'>This footer was included!</span>
  </div>
</nav>