<?php
	// setting the title of this page
	$title = 'Home';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title><?php echo $title; ?></title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
</head>
<body>
<!--
	This example shows how to use PHP's include function to include a navbar.
	It helps us re-use code.
-->
<?php
	include('navbar.php');
?>
<div class="container">

	<h1>This text was not included!</h1>

</div>
<?php
	include('footer.php');
?>
</body>
</html>

